﻿using Practical06.Errors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace Practical06.Errors
{

    public abstract class ErrorMessage

    {

        public ErrorsCode Code { get; set; }
        public string Type { get; set; }
        public string Title { get; set; }
        public string Detail { get; set; }
        public string Instance { get; set; }
        public string Info { get; set; }
    }

    public class RequestContentErrorMessage : ErrorMessage

    {

        public RequestContentErrorMessage()

        {

            Code = ErrorsCode.RequestContentMismatch;

            Type =
            $"https://massrover.com/doc/errors/#{ErrorsCode.RequestContentMismatch.ToString()}";

        }

        public class EntityNotFoundErrorMessage : ErrorMessage

        {

            public EntityNotFoundErrorMessage()

            {

                Code = ErrorsCode.RequestContentMismatch; Type =

                $"https://massrover.com/doc/errors/#{ErrorsCode.EntityNotFound.ToString()}";

            }

        }

    }

}
