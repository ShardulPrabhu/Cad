﻿using System;

using System.Collections.Generic;
using System.IO;
using System.Linq;

using System.Threading.Tasks;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

using Microsoft.Extensions.PlatformAbstractions;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

namespace Practical06

{

    public class Startup

    {

        public Startup(IConfiguration configuration)

        {

            Configuration = Configuration;

        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)

        {

            services.AddMvc(); services.AddSwaggerGen(c =>
            {

                c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo

                {

                    Title = "MassRover API",
                    Version = "v1"
                });



                c.IncludeXmlComments(Path.Combine(PlatformServices.Default.Application.ApplicationBasePath, "Practical06.xml"));

            });

        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)

        {

            if (env.IsDevelopment())

            {

                app.UseDeveloperExceptionPage();

            }

            app.UseSwagger(); app.UseSwaggerUI(s =>
            {

                s.SwaggerEndpoint("/swagger/v1/swagger.json", "MassRover Open API"); s.RoutePrefix = String.Empty;
            });

        }

    }

}
